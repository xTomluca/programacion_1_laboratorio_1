#include <stdio.h>
#include <stdlib.h>
#define CANTIDAD_NUMEROS 10

int main()
{
    float numero;
    float acumulador=0;
    float promedio;
    int i;

    for (i=0; i< CANTIDAD_NUMEROS; i++)
    {
        printf("Ingrese numero ");
        scanf("%f", &numero);
        acumulador = acumulador + numero;
    }
    promedio = acumulador / CANTIDAD_NUMEROS;
    printf("\nEl promedio de los numeros ingresados es: %.2f\n", promedio);

    return 0;
}
